<?php

	require "lib/fonksiyon.php";
	
	print_r(get_headers("http://www.redtube.com/"));