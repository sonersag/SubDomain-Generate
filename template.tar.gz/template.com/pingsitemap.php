<!doctype html><html><head>
<meta charset="utf-8"><style>
html,body{margin:0;padding:0}iframe{border:0}</style>
</head><body><iframe src="#" style="width:100%;height:500px"></iframe></body></html>