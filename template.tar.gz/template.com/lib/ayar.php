<?php
	
	error_reporting(E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED);
	
	$server		=	"localhost";								## Burası sabit kalabilir
	$dbuser		=	"databaseuser";								## Mysql kullanıcı adı	
	$dbpass		=	"iHytYPju";									## Mysql parolası
	$dbadi		=	"databaseadi";								## Mysql db ismi
	$lisanskey	=	"DEABFA1-C0BDD6C-4E40C8C-68FB6A3-3263";		## Lisans Anahtarı
	
?>
